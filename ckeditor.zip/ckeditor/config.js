﻿/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	
	// %REMOVE_START%
	// The configuration options below are needed when running CKEditor from source files.
	
	config.plugins = 'pastetext,footnotes,find,findcust,dialogui,shortcuts,texttransform,formatpainter,dialog,a11yhelp,dialogadvtab,basicstyles,blockquote,clipboard,button,panelbutton,panel,floatpanel,menu,contextmenu,toolbar,elementspath,enterkey,entities,popup,filebrowser,fakeobjects,floatingspace,listblock,richcombo,htmlwriter,wysiwygarea,indent,indentblock,indentlist,justify,menubutton,list,liststyle,magicline,removeformat,save,showborders,tab,table,tabletools,undo,lineutils,widget,symbol,quicktable,tableresize,showblocks,undo,lite,link,simpleLink,title,subtitle,sourcearea,pdfimport,image,preLink,abbr';
	//matheditor,index,indexviewer,stylescombo,colorbutton,print,pastefromword,find,uploadexcelfile,maximize,zoom,createimagegallery,stat,wordcount,nanospell,imagebrowser,,imageuploader
	config.skin = 'office2013';
	config.extraPlugins='blockimagepaste';
	//config.extraPlugins = 'format_buttons';
	config.height = '430px';
	config.allowedContent = true;
	config.entities_processNumerical = true;
	config.entities_processNumerical = 'force';   
	config.basicEntities = false;
	config.disallowedContent = '!br,!i,!em';
	config.autoParagraph=false;
	//config.readOnly = true;
	// %REMOVE_END%
//debugger;
	//config.lite.ignoreSelectors = ["[data-track-changes-ignore]", "[data-footnote-id]", "section.footnotes"];	
	
		    // for  image operation
    config.filebrowserImageBrowseUrl = "ImageBrowser.aspx?t=44048";
    config.filebrowserImageWindowWidth = 780;
    config.filebrowserImageWindowHeight = 720;
};

