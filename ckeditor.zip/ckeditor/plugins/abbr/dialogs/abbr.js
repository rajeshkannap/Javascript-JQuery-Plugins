var diagbody=null;
var xhtest="";
CKEDITOR.dialog.add( 'archDialog', function( editor ) {
    return {
        title: 'Archive Articles',
        minWidth: 700,
        minHeight: 80,
        contents: [
            {
                id: 'lbl-dialouge',
                label: 'Archive Articles',
                elements: [
                    {
                        type: 'html',
                        id: 'articlelist',
                        html:'test'
                    }
                ]
            }
                ],
           

			onShow: function() {
						this.parts.contents.$.childNodes[0].getElementsByClassName("cke_dialog_ui_html")[0].innerHTML='<div style="height:400px; overflow-y:scroll;">'+xhtest+'</div>';
						diagbody=this.parts.contents.$.childNodes[0].getElementsByClassName("cke_dialog_ui_html")[0];
				},
				onLoad : function() {
					//console.log(this);
					var request = new XMLHttpRequest();
					request.open("GET", "ckeditor/" + CKEDITOR.plugins.basePath + "abbr/config/config.html", false);
					request.send();
					xhtest = request.responseText;
					xhtest = xhtest.replace(/<li number([^<>]+)>(.*?)<\/li>/gi, "<li><input type='radio' name='radio' id$1/><span>$2</span></li>");
					xhtest = xhtest.replace(/<\/?(html|body)>/gi, "");
					xhtest = xhtest.replace(/<\?xml version=\"1\.0\"\?>/gi, "");
				},
        onOk: function() {
            //alert(getSelectedItem());
            selid = getSelectedItem();
							var selectcont = editor.getSelection().getSelectedText().toString();
							console.log(selectcont);
							var range = editor.getSelection().getRanges()[0];
							var documentFragment = range.extractContents();
							var btnTagName = 'a';
            debugger;
							var insertTag = editor.document.createElement(btnTagName);
							insertTag.setAttribute('href', selid);
							insertTag.append(documentFragment);
							editor.insertElement(insertTag);

        }
    };
});


getSelectedItem=function(){
	var inputs=diagbody.getElementsByTagName("input");
	for(x=0; x<inputs.length;x++)
	{
	  if(inputs[x].checked)
	  {
	    return 	inputs[x].id;
	  }	
	}
	}