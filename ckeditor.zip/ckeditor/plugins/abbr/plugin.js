﻿
CKEDITOR.plugins.add( 'abbr', {
    icons: 'abbr',
    init: function( editor ) {
    	editor.addCommand( 'abbr', new CKEDITOR.dialogCommand( 'archDialog' ) );
    	editor.ui.addButton( 'Abbr', {
			    label: 'Insert Query',
			    command: 'abbr',
			    //toolbar: '10',
			    //toolbar: 'query,10',
			    icon : CKEDITOR.plugins.getPath('abbr') + 'img/' + 'style.png',

			});
			 CKEDITOR.dialog.add( 'archDialog', this.path + 'dialogs/abbr.js' );
        // Plugin logic goes here...
		
    }
} );
