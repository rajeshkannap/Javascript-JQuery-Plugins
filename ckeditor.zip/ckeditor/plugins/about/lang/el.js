﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'el', {
	copy: 'Πνευματικά δικαιώματα &copy; $1 Με επιφύλαξη παντός δικαιώματος.',
	dlgTitle: 'Περί του CKEditor',
	help: 'Ελέγξτε τις $1 για βοήθεια.',
	moreInfo: 'Για πληροφορίες σχετικές με την άδεια χρήσης, παρακαλούμε επισκεφθείτε την ιστοσελίδα μας:',
	title: 'Περί του CKEditor',
	userGuide: 'Οδηγίες Χρήστη CKEditor'
} );
