﻿CKEDITOR.plugins.setLang( 'autocorrect', 'en', {
	toolbar: 'AutoCorrect',
	disable: 'Disable AutoCorrect',
	enable: 'Enable AutoCorrect',
	apply: 'AutoCorrect Now'
});
