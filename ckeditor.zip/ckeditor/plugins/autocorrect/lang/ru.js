﻿CKEDITOR.plugins.setLang( 'autocorrect', 'ru', {
	toolbar: 'Автозамена',
	disable: 'Отключить автозамену',
	enable: 'Включить автозамену',
	apply: 'Произвести автозамену'
});
