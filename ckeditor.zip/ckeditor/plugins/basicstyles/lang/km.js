﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'km', {
	bold: 'ដិត',
	italic: 'ទ្រេត',
	strike: 'គូស​បន្ទាត់​ចំ​កណ្ដាល',
	subscript: 'អក្សរតូចក្រោម',
	superscript: 'អក្សរតូចលើ',
	underline: 'គូស​បន្ទាត់​ក្រោម'
} );
