CKEDITOR.dialog.add( 'abbrDialog', function( editor ) {
    return {
        title: 'Content Manager Query',
        minWidth: 400,
        minHeight: 80,
        contents: [
            {
                id: 'tab-basic',
                label: 'Insert Query',
                elements: [
                    {
                        type: 'text',
                        id: 'title',
                        label: 'Query',
                        validate: CKEDITOR.dialog.validate.notEmpty( "Explanation field cannot be empty." )
                    }
                ]
            },
//            {
//                id: 'tab-adv',
//                label: 'Query Reply',
//                elements: [
//                    {
//                        type: 'text',
//                        id: 'id',
//                        label: 'Id'
//                    }
//                ]
//            }
        ],
        onOk: function() {
            var dialog = this;
            var abbr = editor.document.createElement( 'named-content' );
						var idcount = 'aq' + (editor.document.$.getElementsByTagName('named-content').length + 1);
            //abbr.setAttribute( 'title', dialog.getValueOf( 'tab-basic', 'title' ) );
            //var queryPrefixabbr = editor.document.createElement( 'bold');
            //queryPrefixabbr.setText('Query: ');
            //abbr.append(queryPrefixabbr);
            
            abbr.setAttribute('content-type', 'query');
						abbr.setAttribute('id', idcount);
            var textboxNode = editor.document.createText(dialog.getValueOf( 'tab-basic', 'title' ));
            abbr.append( textboxNode );
            debugger;
            //abbr.setText( queryPrefixabbr + dialog.getValueOf( 'tab-basic', 'title' ) );
            //abbr.setText('Query');
//            var id = dialog.getValueOf( 'tab-adv', 'id' );
//            if ( id )
//              abbr.setAttribute( 'id', id );
            editor.insertElement( abbr );
        }
    };
});