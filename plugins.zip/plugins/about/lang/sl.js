﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'sl', {
	copy: 'Copyright &copy; $1. Vse pravice pridržane.',
	dlgTitle: 'O programu CKEditor',
	help: 'Preverite $1 za pomoč.',
	moreInfo: 'Za informacijo o licenci prosim obiščite našo spletno stran:',
	title: 'O programu CKEditor',
	userGuide: 'CKEditor Navodila za Uporabo'
} );
