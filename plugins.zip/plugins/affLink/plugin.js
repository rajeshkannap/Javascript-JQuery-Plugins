/**
 * Lumina Datamtics Ltd d.
 * Doi Insertion plugin for CKEditor
 */
var CKeditor = null;
var dataFromTag;
CKEDITOR.plugins.add('affLink', {
	init: function (editor) {
		CKeditor = editor;
		var affLinkAction = function () {
			debugger;
			var editorXml = editor.document; // [object Object] ... CKEditor object
			var xmldocNode = editorXml.$; // [object HTMLDocument] .... DOM object
			var frontCollection = xmldocNode.getElementsByTagName('front');
			//console.log(frontCollection.length);
			for (i = frontCollection.length - 1; i >= 0; i--) {
				
				var affHash = {};
				//for (i = 0; i < frontCollection.length; i++) {
				eachFronts = frontCollection[i];
				var contGroups = frontCollection[i].getElementsByTagName('author-group');
				//console.log(contGroups.length);
				
				for (a = frontCollection.length - 1; a >= 0; a--) {
					eachtblfnote = contGroups[a];
					var affCollection = frontCollection[0].getElementsByTagName('aff');
					console.log(affCollection.length);
					for (b = affCollection.length - 1; b >= 0; b--) {
						eachFn = affCollection[b];
						var attValue = eachFn.getAttribute('id');
						var labelNode = eachFn.getElementsByTagName('label');
						var labelValue = labelNode[0].firstChild.nodeValue;
						affHash[labelValue] = attValue;
					}

				}
				if (contGroups.length > 0) {
					Object.keys(affHash).forEach(function (key) {
						
						var idValue = affHash[key];
						// iteration code
						//alert(key + idValue);
						//var tableNum=new RegExp("[0-9]+");
						var affNumFind = key;

						contGroups[0].innerHTML = eval("contGroups[0].innerHTML.replace(/<sup>" + affNumFind + "([\\,\\*]*)<\\/sup>/g, '<sup><a href=" + '"' + idValue + '"' + " ref-type=" + '"aff' + '">' + affNumFind + "<\/a>$1</sup>')");
//						contGroups[0].innerHTML = eval("contGroups[0].innerHTML.replace(/<sup>" + affNumFind + "<\\/sup>/g, '<sup><a href=" + '"' + idValue + '"' + " ref-type=" + '"aff' + '">' + affNumFind + "<\/a></sup>')");
						
						//console.log('true');

					})

				}
				//alert(labelNode[0].firstChild.nodeValue);
				//alert(affHash[labelValue]);


			}

			
			var remCollection = xmldocNode.getElementsByTagName('label');
			for (i = 0; i < remCollection.length; i++) {
				var aCollection = remCollection[i].getElementsByTagName('a');
				if (aCollection.length > 0) {
					var contents = remCollection[i].getElementsByTagName('a')[0].innerHTML;
					var selText = remCollection[i].getElementsByTagName('a')[0];
					remCollection[i].innerHTML = eval("remCollection[i].innerHTML.replace(/" + selText.outerHTML.replace("</a>", "<\\/a>") + "/g,'" + contents + "')");
					
					console.log('true');
				}

			}

		}
		editor.addCommand('affLink', new CKEDITOR.command(editor, {
				exec: affLinkAction
			}));
//		editor.ui.addButton('affLink', {
//			label: 'Affiliation Links',
//			command: 'affLink',
//			//icon: CKEDITOR.plugins.getPath('affLink') + 'img/' + 'style.jpg',
//			click: affLinkAction
//		});

	}
});
