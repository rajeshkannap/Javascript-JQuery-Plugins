/**
 * Lumina Datamtics Ltd.
 * Ref Label Insertion plugin for CKEditor
*/
var CKeditor = null;
var runAutoStyle;
var runKwdStyle;
var runAffStyle;
var callrefScript;
var calldoiInsert;
var callpubmedInsert;
var callpubmedInsert1;
var callpubmedIdInsert;
CKEDITOR.plugins.add('autostyle', {
	init : function (editor) {
		CKeditor = editor;
		editor.addCommand('autostyle', new CKEDITOR.dialogCommand('autostyle'));
		editor.ui.addButton('autostyle', {
			label : 'Auto Styling',
			command : 'autostyle',
			toolbar: 'tetools,20',
			icon : CKEDITOR.plugins.getPath('autostyle') + 'img/' + 'style.png',
			click : function () {
					//destroy old dialog
					
					if ($("#dialog-1").dialog("isOpen") == true) {
					    $("#dialog-1").dialog("close");
					} if ($("#dialog-2").dialog("isOpen") == true) {
					    $("#dialog-2").dialog("close");
					} if ($("#dialog-3").dialog("isOpen") == true) {
					    $("#dialog-3").dialog("close");
					} if ($("#dialog-4").dialog("isOpen") == true) {
					    $("#dialog-4").dialog("close");
					} if ($("#dialog-5").dialog("isOpen") == true) {
					    $("#dialog-5").dialog("close");
					} if ($("#ceTools_dialog").dialog("isOpen") == true) {
					    $("#ceTools_dialog").dialog("close");
					}
					// open dialog to process
					$("#dialog-6").dialog("open");
			}
		});


		// Selection style apply
//		function autoGetSelectedText (self) {
//			//
//			if (editor) { // all browsers, except IE before version 9
//				var btnTagName = self.attributes['data-tag'].value;
//				var range = editor.getSelection().getRanges()[0];
//				var documentFragment = range.extractContents();
//				if(btnTagName == 'body') {
//					btnTagName = 'article-body';
//				}
//				var insertTag = editor.document.createElement(btnTagName);
//				insertTag.append(documentFragment);
//				editor.insertElement(insertTag);
//			}
//		}
		// <input type="button" value="Call Perl Script" onclick="callScript()"  /> -->
		callrefScript = function (){
		   //$.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"cgi-bin\\ref-auto-style.pl", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
		   $.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"ref_auto_style", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
					if(data.match(/<ref-list> not found/)) {
						alert("<ref-list> not found...");
					} else {
						var neweditorXml = CKeditor.document; // [object Object] ... CKEditor object
						var xmldocrefNode = neweditorXml.$; // [object HTMLDocument] .... DOM object
						var refGrp = xmldocrefNode.getElementsByTagName('ref-list');
						refGrp[0].innerHTML=data;
					  msg.data('messageBox').default('Reference Style Completed');
					}
		   });
		}
		calldoiInsert = function (){
		   //$.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"cgi-bin\\ref-style-doi.pl", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
		   $.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"ref-style-doi", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
					if(data.match(/<ref-list> not found/)) {
						alert("<ref-list> not found...");
					} else {
						var neweditorXml = CKeditor.document; // [object Object] ... CKEditor object
						var xmldocrefNode = neweditorXml.$; // [object HTMLDocument] .... DOM object
						var refGrp = xmldocrefNode.getElementsByTagName('ref-list');
						refGrp[0].innerHTML=data;
					  msg.data('messageBox').default('DOI Insertion Completed');
				  }
		   });
		}
		
		
		callpubmedIdInsert = function () {
		  debugger;
				var neweditorXml = CKeditor.document; // [object Object] ... CKEditor object
				var xmldocrefNode = neweditorXml.$; // [object HTMLDocument] .... DOM object
				var refGrp = xmldocrefNode.getElementsByTagName('ref-list');
				refGrp[0].setAttribute('pubmed','Started');
				CKEDITOR.setLoading(true);
				callpubmedInsert();

				var myVar = setInterval(function(){ 
					var neweditorXml = CKeditor.document; // [object Object] ... CKEditor object
					var xmldocrefNode = neweditorXml.$; // [object HTMLDocument] .... DOM object
					var refGrp = xmldocrefNode.getElementsByTagName('ref-list')[0];
					var attVal=refGrp.getAttribute('pubmed');
					if (attVal == "Completed"){
						debugger;
						clearInterval(myVar);
						CKEDITOR.setLoading(false);
						msg.data('messageBox').default('Pubmed-ID Insertion Completed!');
						refGrp.removeAttribute('pubmed');
					}					
				}, 2000);		
				
		}
		
		callpubmedInsert = function (){
			
		   //$.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"cgi-bin\\Pubmed_IDIns.pl", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
		   $.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"Pubmed_IDIns", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
					if(data.match(/<ref-list> not found/)) {
						CKEDITOR.setLoading(false);
						alert("<ref-list> not found...");
					} else {
						var neweditorXml = CKeditor.document; // [object Object] ... CKEditor object
						debugger;
						var xmldocrefNode = neweditorXml.$; // [object HTMLDocument] .... DOM object
						var refGrp = xmldocrefNode.getElementsByTagName('ref-list');
						refGrp[0].innerHTML=data;
						refGrp[0].setAttribute('pubmed','Completed');
					}
		   });
		   return true;
		}
		callpubmedInsert1 = function (){
		   debugger;
		   $.ajax(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"cgi-bin\\Pubmed_IDIns.pl", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
		   	
					if(data.match(/<ref-list> not found/)) {
						alert("<ref-list> not found...");
					} else {
						var neweditorXml = CKeditor.document; // [object Object] ... CKEditor object
						debugger;
						var xmldocrefNode = neweditorXml.$; // [object HTMLDocument] .... DOM object
						var refGrp = xmldocrefNode.getElementsByTagName('ref-list');
						refGrp[0].innerHTML=data;						
					}
			success: alert("completed");
		   });
		}
		callAPAStyle = function () {
		   //$.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"cgi-bin\\HK_APA_ref.pl", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
		   $.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"HK_APA_ref", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
					if(data.match(/<ref-list> not found/)) {
						alert("<ref-list> not found...");
					} else {
						var neweditorXml = CKeditor.document; // [object Object] ... CKEditor object
						var xmldocrefNode = neweditorXml.$; // [object HTMLDocument] .... DOM object
						var refGrp = xmldocrefNode.getElementsByTagName('ref-list');
						refGrp[0].innerHTML=data;
					  msg.data('messageBox').default('APA Ref Style Completed');
					}
		   });
		}

		callAMAStyle = function (){
		   //$.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"cgi-bin\\HK_AMA_ref.pl", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
		   $.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"HK_AMA_ref", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
					if(data.match(/<ref-list> not found/)) {
						alert("<ref-list> not found...");
					} else {
						var neweditorXml = CKeditor.document; // [object Object] ... CKEditor object
						var xmldocrefNode = neweditorXml.$; // [object HTMLDocument] .... DOM object
						var refGrp = xmldocrefNode.getElementsByTagName('ref-list');
						refGrp[0].innerHTML=data;
					  msg.data('messageBox').default('AMA Ref Style Completed');
					}
		   });
		}
		callVANStyle = function (){
		   //$.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"cgi-bin\\HK_VAN_ref.pl", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
		   $.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"HK_VAN_ref", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
					if(data.match(/<ref-list> not found/)) {
						alert("<ref-list> not found...");
					} else {
						var neweditorXml = CKeditor.document; // [object Object] ... CKEditor object
						var xmldocrefNode = neweditorXml.$; // [object HTMLDocument] .... DOM object
						var refGrp = xmldocrefNode.getElementsByTagName('ref-list');
						refGrp[0].innerHTML=data;
					  msg.data('messageBox').default('VAN Ref Style Completed');
					}
		   });
		}


		callAuthorScript = function (){
		   //$.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"cgi-bin\\authorstyle.pl", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
		   $.post(window.location.protocol+"\\\\"+window.location.hostname+"\\"+"capsjournals\\"+"authorstyle", {'txt_content': JSON.parse(captureUrlFields()).folderCode}, function(data){
					if(data.match(/<author-group> not found/)) {
						alert("<author-group> not found...");
					} else {
						var neweditorXml = CKeditor.document; // [object Object] ... CKEditor object
						var xmldocrefNode = neweditorXml.$; // [object HTMLDocument] .... DOM object
						var refGrp = xmldocrefNode.getElementsByTagName('author-group');
						refGrp[0].innerHTML=data;
					  msg.data('messageBox').default('Author Style Completed');
					}
		   });
		}

		
		function dataFromTag (node, t) {
			var d = node.getElementsByTagName(t);
			if (d.length == 0)
				return ('');
			return (d[0].firstChild.nodeValue);
		}
		function dataFromAtt (node, t) {
			var d = node.getAttribute(t);
			if (d.length == 0)
				return ('');
			return (d);
		}
		
		function rename_element(node,name) {
		    var renamed = document.createElement(name); 
		    if(name == 'aff') {
		    	
			    	node.innerHTML = node.innerHTML.replace(/^<sup>([0-9])<\/sup>/g,'<label>$1<\/label>');
		  	}
		    while (node.firstChild) {
		        renamed.appendChild(node.firstChild);
		    }
		    return node.parentNode.replaceChild(renamed, node);
		}

		function rename_sec_element(node,name,lev) {
		    var renamed = document.createElement(name); 
  	    renamed.setAttribute('level', lev);
		    while (node.firstChild) {
		        renamed.appendChild(node.firstChild);
		    }
		    return node.parentNode.replaceChild(renamed, node);
		}

		

		runAffStyle = function (){
			msg.data('messageBox').default('Work in Progress');
		}
		
		runKwdStyle = function (){
			debugger;
					var editorXml = editor.document; // [object Object] ... CKEditor object
					var xmldocNode = editorXml.$; // [object HTMLDocument] .... DOM object
   				var kwdGrp = xmldocNode.getElementsByTagName('kwd-group');
   				debugger;
		   		kwdGrp[0].innerHTML = kwdGrp[0].innerHTML.replace(/\&([#a-z0-9]+)\;/g,'\[\[$1\]\]');
   				//$Keyword =~ s/\&([#a-z0-9]+)\;/\[\[\&$1\]\]/sig;
		   		//kwdGrp[0].innerHTML = kwdGrp[0].innerHTML.replace(/\s+/g,'');
		   		kwdGrp[0].innerHTML = kwdGrp[0].innerHTML.replace(/([\,\:\.\;]+)\s*(<\/kwd>)/g,'$2$1');
		   		//kwdGrp[0].innerHTML = kwdGrp[0].innerHTML.replace(/\s+/g,'');
		   		kwdGrp[0].innerHTML = kwdGrp[0].innerHTML.replace(/<span[^><]+>(.*?)<\/span>/g,'$1');
					kwdGrp[0].innerHTML = (kwdGrp[0].innerHTML.replace(/^\s?(?:<B>)?(?:<I>)?((?:Author )?Key ?[Ww]ords?)(?:<\/I>)?(?:<\/B>)?(\:|\-|&ndash;|&#8212;|&mdash;|\-)\s?/ig, "<kwdtitle>$1 $2<\/kwdtitle> "));
					kwdGrp[0].innerHTML = (kwdGrp[0].innerHTML.replace(/^\s?(?:<bold>)?(?:<italic>)?((?:Author )?Key ?[Ww]ords?)(?:<\/italic>)?(?:<\/bold>)?( ?\: ?| ?\- ?| ?&ndash; ?| ?&#8212; ?| ?&mdash; ?)\s?/ig, "<kwdtitle>$1$2<\/kwdtitle> "));
					
					
					kwdGrp[0].innerHTML = (kwdGrp[0].innerHTML.replace(/^\s?(?:<italic>)?(?:<bold>)?((?:Author )?Key ?[Ww]ords?)(?:<\/bold>)?(?:<\/italic>)?( ?\: ?| ?\- ?| ?&ndash; ?| ?&#8212; ?| ?&mdash; ?)?\s?/ig, "<kwdtitle>$1$2<\/kwdtitle> "));
					
					//kwdGrp[0].innerHTML = (kwdGrp[0].innerHTML.replace(/(<\/kwdtitle>[\:\s]*)(.*?)(\; ?|\, |\.?$)/ig, "$1<kwd>$2<\/kwd>$3"));
					
					if(kwdGrp[0].innerHTML.match(/(<\/kwdtitle>[\:\s]*)([^\,]+)(\,)/)) {
						kwdGrp[0].innerHTML = (kwdGrp[0].innerHTML.replace(/(<\/kwdtitle>[\:\s]*)([^\,]+)(\,)/ig, "$1<kwd>$2<\/kwd>$3"));
					} else if(kwdGrp[0].innerHTML.match(/(<\/kwdtitle>[\:\s]*)([^\;]+)(\;)/)) {
						kwdGrp[0].innerHTML = (kwdGrp[0].innerHTML.replace(/(<\/kwdtitle>[\:\s]*)([^\;]+)(\;)/ig, "$1<kwd>$2<\/kwd>$3"));
					}

   				
   				//while (kwdGrp[0].innerHTML != (kwdGrp[0].innerHTML = kwdGrp[0].innerHTML.replace(/<\/kwd>([\,\:\;  ><]+)(.*?)(\; ?|\, ?|\s |\.?$)/g, '<\/&del;kwd>$1<kwd>$2<\/kwd>$3'))){}
   				
   				while (kwdGrp[0].innerHTML != (kwdGrp[0].innerHTML = kwdGrp[0].innerHTML.replace(/<\/kwd>([\,\:\; ]+)([^\;\,]+)(\; ?|\, ?|\.?$)/g, '<\/&del;kwd>$1<kwd>$2<\/kwd>$3'))){}
   				
		   		kwdGrp[0].innerHTML = kwdGrp[0].innerHTML.replace(/!--&del\;kwd--/g,'\/kwd');
		   		kwdGrp[0].innerHTML = kwdGrp[0].innerHTML.replace(/\[\[([#a-z0-9]+)\]\]/g,'\&$1\;');
		   		
		   		kwdGrp[0].innerHTML = kwdGrp[0].innerHTML.replace(/<kwd>&nbsp;/g,'&nbsp;<kwd>');
		   		
		   		msg.data('messageBox').default('Keyword Style Completed');
		}
		
		// Auto Styleing
		runAutoStyle = function (seclev) {
			//var seclevFormat = seclev.value;
			var seclevFormat = '1.1';
			// xml file handling
			var editorXml = editor.document; // [object Object] ... CKEditor object
			var xmldocNode = editorXml.$; // [object HTMLDocument] .... DOM object

			// front Matter Process
			var frontGroup = xmldocNode.getElementsByTagName('front');
			var frontparaCollection = frontGroup[0].getElementsByTagName('p');
			if(frontparaCollection[0]) {
				rename_element(frontparaCollection[0], 'article-title');
			}
			if(frontparaCollection[0]) {
				rename_element(frontparaCollection[0], 'author-group');
			}
				//debugger;

			for (i = 0; i < frontparaCollection.length; i++) {
				var frontpara = frontparaCollection[i];
				var parawordCount = frontpara.innerHTML.split(' ').length;
				//alert(paraword);
				if(frontpara.innerHTML.match(/^(<sup>[0-9a-z]<\/sup>)/)) {
					rename_element(frontpara, 'aff');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/^(<sup>\*<\/sup>|\*)/)) {
					rename_element(frontpara, 'corresp');
					i = i-1;
				}
					
				if(frontpara.innerHTML.match(/^(Abstract)/) && frontpara.innerHTML.length < 15) {
					rename_element(frontpara, 'abstract-title');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/^(Abstract|Abstracts)/) && frontpara.innerHTML.length < 15) {
					rename_element(frontpara, 'abstract-title');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/^(<bold>Abstracts?)/) && frontpara.innerHTML.length < 35) {
					rename_element(frontpara, 'abstract-title');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/^(<b>Abstracts?)/) && frontpara.innerHTML.length < 35) {
					rename_element(frontpara, 'abstract-title');
					i = i-1;
				}
				if(frontpara.innerHTML.split(' ').length > 30) {
					rename_element(frontpara, 'abstract');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/^(<bold>(Methods|Background))/)) {
					rename_element(frontpara, 'abstract');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/^(<b>(Author )?[kK]eywords:?<\/b>)/)) {
					rename_element(frontpara, 'kwd-group');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/^(<(bold|italic)>Key Words:<\/(bold|italic)>)/)) {
					rename_element(frontpara, 'kwd-group');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/^Key ?[Ww]ords?\s?\:/)) {
					rename_element(frontpara, 'kwd-group');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/(<(bold|italic)>KeyWords:<\/(bold|italic)>)/)) {
					rename_element(frontpara, 'kwd-group');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/(<(bold|italic)>Key Words<\/(bold|italic)>)/)) {
					rename_element(frontpara, 'kwd-group');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/(<(bold|italic)>Keywords<\/(bold|italic)>)/)) {
					rename_element(frontpara, 'kwd-group');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/(<italic><bold>Keywords<\/bold><\/italic>)/)) {
					rename_element(frontpara, 'kwd-group');
					i = i-1;
				}
				if(frontpara.innerHTML.match(/(Received)/i) && frontpara.innerHTML.match(/(accepted|revised)/i)) {
					rename_element(frontpara, 'history');
					i = i-1;
				}
			}
			// End Front Matter Process
			
			
			// body matter process
			//
			var bodyGroup = xmldocNode.getElementsByTagName('article-body');
			var paraCollection = bodyGroup[0].getElementsByTagName('p');
			
			for (i = 0; i < paraCollection.length; i++) {
					eachpara = paraCollection[i];
					
					if(eachpara.innerHTML.match(/^(<bold>)?[Ii]ntroduction(<\/bold>)?$/)) {
						//rename_element(eachpara, 'heading1');
						rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					} else if(eachpara.innerHTML.match(/^(1\. ?|1\.? |1\.1 )[Ii]ntroduction$/)) {
						//eachpara.setAttribute('level', '1');
						rename_sec_element(eachpara, 'sec', '1');

						//rename_element(eachpara, 'heading1');
						i = i-1;
					}
					//Section check
					if(seclevFormat.match(/(\#\.\#|[0-9]\.[0-9])/)) {
						if(eachpara.innerHTML.match(/^([0-9]\.[0-9] )[A-Z][a-z]+/) && eachpara.innerHTML.split(' ').length < 15) {
							previousElementSib = eachpara.previousElementSibling;
							//rename_element(eachpara, 'heading2');
							rename_sec_element(eachpara, 'sec', '2');
							if(previousElementSib.innerHTML.match(/^([0-9]\. ?)[A-Z][a-z]+/) && previousElementSib.innerHTML.split(' ').length < 10) {
								//rename_element(previousElementSib, 'heading1');
								rename_sec_element(previousElementSib, 'sec', '1');
							}
							i = i-1;
						}
						if(eachpara.innerHTML.match(/^([0-9]\.[0-9]\.[0-9] )[A-Z][a-z]+/) && eachpara.innerHTML.split(' ').length < 15) {
							//rename_element(eachpara, 'heading3');
							rename_sec_element(eachpara, 'sec', '3');
							i = i-1;
						}
					} else if(seclevFormat.match(/(#\-#|[0-9]\-[0-9])/)) {
						if(eachpara.innerHTML.match(/^([0-9]\-[0-9] )[A-Z][a-z]+/) && eachpara.innerHTML.split(' ').length < 15) {
							//rename_element(eachpara, 'heading2');
							rename_sec_element(eachpara, 'sec', '2');
							i = i-1;
						}
						if(eachpara.innerHTML.match(/^([0-9]\-[0-9]\-[0-9] )[A-Z][a-z]+/) && eachpara.innerHTML.split(' ').length < 15) {
							//rename_element(eachpara, 'heading3');
							rename_sec_element(eachpara, 'sec', '3');
							i = i-1;
						}
					}
					//Equation check
					if(eachpara.innerHTML.match(/^<inline-formula><img [^><]+><\/inline-formula>\([0-9]+\)$/)) {
						eachpara.innerHTML = eachpara.innerHTML.replace(/^<inline-formula>(<img [^><]+>)<\/inline-formula>(\([0-9]+\))$/,'<disp-formula>$1<label>$2</label><\/disp-formula>');
						rename_element(eachpara, 'equation');
						i = i-1;
					}
					if(eachpara.innerHTML.match(/^<disp-formula><img [^><]+><\/disp-formula>\([0-9]+\)$/)) {
						eachpara.innerHTML = eachpara.innerHTML.replace(/<\/disp-formula>(\([0-9]+\))$/,'<label>$1</label><\/disp-formula>');
						rename_element(eachpara, 'equation');
						i = i-1;
					}

					if(eachpara.innerHTML.match(/^(<bold>)?(Experiment)(<\/bold>)?$/)) {
						//rename_element(eachpara, 'heading1');
						rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					} else if(eachpara.innerHTML.match(/^([0-9]\.? |[0-9]\. ?)Experiment$/)) {
						//rename_element(eachpara, 'heading1');
						rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					}
					//alert(eachpara.innerHTML);
					if(eachpara.innerHTML.match(/^(Fig\.? )[0-9]+\.?/) && eachpara.innerHTML.split(' ').length < 60) {
						eachpara.innerHTML = eachpara.innerHTML.replace(/^((Fig\.? )[0-9]+\.?)/,'<label>$1</label>');
						rename_element(eachpara, 'fig');
						
						i = i-1;
					} else if(eachpara.innerHTML.match(/^(Figure\.? )[0-9]+\.?/) && eachpara.innerHTML.split(' ').length < 60) {
						eachpara.innerHTML = eachpara.innerHTML.replace(/^((Figure\.? )[0-9]+\.?)/,'<label>$1</label>');
						rename_element(eachpara, 'fig');
						i = i-1;
					}

					if(eachpara.innerHTML.match(/^(Table )([0-9]+|(I|II|III|[IVX]{1,2}))\.?/) && eachpara.innerHTML.split(' ').length < 40) {
						eachpara.innerHTML = eachpara.innerHTML.replace(/^((Table )([0-9]+|(I|II|III|[IVX]{1,2}))\.?)/,'<label>$1</label>');
						rename_element(eachpara, 'tablecaption');
						i = i-1;
					}
					
					if(eachpara.innerHTML.match(/^(<bold>)?(Summary)(<\/bold>)?$/)) {
						//rename_element(eachpara, 'heading1');
						rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					} else if(eachpara.innerHTML.match(/^([0-9]\.? |[0-9]\. ?)Summary$/)) {
						//rename_element(eachpara, 'heading1');
						rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					}
					
					if(eachpara.innerHTML.match(/^(?:<bold>)?(Conclusions?)(?:<\/bold>)?$/)) {
						//rename_element(eachpara, 'heading1');
						rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					} else if(eachpara.innerHTML.match(/^([0-9]\.? |[0-9]\. ?)Conclusions?$/)) {
						//rename_element(eachpara, 'heading1');
						rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					}
					
					if(eachpara.innerHTML.match(/^(<bold>)?(Results and Discussion)(<\/bold>)?$/)) {
						//rename_element(eachpara, 'heading1');
						rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					} else if(eachpara.innerHTML.match(/^([0-9]\.? |[0-9]\. ?)Results and Discussion$/)) {
						//rename_element(eachpara, 'heading1');
						rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					}
					
			}

			// Back matter process
			//
			var backGroup = xmldocNode.getElementsByTagName('back');
			var backparaCollection = backGroup[0].getElementsByTagName('p');
			
			for (i = 0; i < backparaCollection.length; i++) {
					eachpara = backparaCollection[i];
					debugger;
					if(eachpara.innerHTML.match(/^Acknowledge?ments? ?$/)) {
						if(backparaCollection[1]) {
							rename_element(backparaCollection[1], 'ack-para');
						}
						rename_element(eachpara, 'ack-title');
						//rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					} else if(eachpara.innerHTML.match(/^<bold>Acknowledge?ments? ?<\/bold>$/)) {
						//rename_element(eachpara, 'heading1');
						if(backparaCollection[1]) {
							rename_element(backparaCollection[1], 'ack-para');
						}
						rename_element(eachpara, 'ack-title');
						i = i-1;
					} else if(eachpara.innerHTML.match(/([0-9]\.? |[0-9]\. ?)Acknowledge?ments$/)) {
						if(backparaCollection[1]) {
							rename_element(backparaCollection[1], 'ack-para');
						}
						rename_element(eachpara, 'ack-title');
						//rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					}

					if(eachpara.innerHTML.match(/^(References?|Bibi?liography)$/)) {
						//rename_element(eachpara, 'heading1');
						//rename_sec_element(eachpara, 'sec', '1');
						rename_element(eachpara, 'ref-title');
						i = i-1;
					} else if(eachpara.innerHTML.match(/^<bold>(References?|Bibi?liography)<\/bold>$/)) {
						//rename_element(eachpara, 'heading1');
						//rename_sec_element(eachpara, 'sec', '1');
						rename_element(eachpara, 'ref-title');
						i = i-1;
					} else if(eachpara.innerHTML.match(/^([0-9]\.? |[0-9]\. ?)(References?|Bibi?liography)$/)) {
						//rename_element(eachpara, 'heading1');
						//rename_sec_element(eachpara, 'sec', '1');
						rename_element(eachpara, 'ref-title');
						i = i-1;
					}
					//alert(eachpara.innerHTML);
					if(eachpara.innerHTML.match(/^(Fig\.? )[0-9]+\.?/) && eachpara.innerHTML.split(' ').length < 60) {
						eachpara.innerHTML = eachpara.innerHTML.replace(/^((?:<bold>)?(Fig\.? )[0-9]+\.?)/,'<label>$1</label>');
						rename_element(eachpara, 'fig');
						
						i = i-1;
					} else if(eachpara.innerHTML.match(/^(Figure\.? )[0-9]+\.?/) && eachpara.innerHTML.split(' ').length < 60) {
						eachpara.innerHTML = eachpara.innerHTML.replace(/^((?:<bold>)?(Figure\.? )[0-9]+\.?)/,'<label>$1</label>');
						rename_element(eachpara, 'fig');
						i = i-1;
					}

					if(eachpara.innerHTML.match(/^(Appendix)$/)) {
						//rename_element(eachpara, 'heading1');
						rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					} else if(eachpara.innerHTML.match(/^<bold>(Appendix)<\/bold>$/)) {
						//rename_element(eachpara, 'heading1');
						rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					} else if(eachpara.innerHTML.match(/^([0-9]\.? |[0-9]\. ?)Appendix$/)) {
						//rename_element(eachpara, 'heading1');
						rename_sec_element(eachpara, 'sec', '1');
						i = i-1;
					}
			}
			
			var refGroup = xmldocNode.getElementsByTagName('ref-list');
			var refparaCollection = refGroup[0].getElementsByTagName('p');
			for (d = 0; d < refparaCollection.length; d++) {
						eachrefpara = refparaCollection[d];
						if(eachrefpara.innerHTML.match(/^<bold>/) && eachrefpara.innerHTML.match(/<\/bold>$/)) {
							eachrefpara.innerHTML = eachrefpara.innerHTML.replace(/<bold>/g,'');
							eachrefpara.innerHTML = eachrefpara.innerHTML.replace(/<\/bold>/g,'');
						}
						rename_element(eachrefpara, 'reference');
						d = d-1;
			}
			msg.data('messageBox').default('Auto Style Completed !');
			
	
		}
		
		
		// Adding Linkdialog to the body
			var dialog = document.createElement('div');
			dialog.id = "dialog-6";
			dialog.setAttribute('title', 'Auto Style Manager');

			var optionTag = document.createElement('span');
			optionTag.setAttribute('style', 'font-weight: bold;');
			
			// Step 1:
			var labeltextNode = document.createTextNode('Step 1: Seperate Divisions:');
			optionTag.appendChild(labeltextNode);
			//dialog.appendChild(optionTag);
			

//			var break2Tagname = document.createElement('br');
//			dialog.appendChild(break2Tagname);
//			var break3Tagname = document.createElement('br');
//			dialog.appendChild(break3Tagname);

			var partStyles = ['Front','Body','Back'];
			// Tag insertion function
			var autoGetSelectedText=function  (self) {
				var btnTagName = this.attributes['data-tag'].value;
				if(CKeditor.getSelection().getType()!=1)
				{
					var range=CKeditor.getSelection().getRanges(true)[0];
					if(btnTagName == 'body') {
						btnTagName = 'article-body';
					}
				 var newElem=document.createElement(btnTagName);
				 var emphasisTags = ['bold','b','em','italic','i','u','underline'];
				 var check=0;
					var Elem=(emphasisTags.indexOf(range.startContainer.$.parentElement.nodeName.toLowerCase())==-1?range.startContainer.$.parentElement:range.startContainer.$.parentElement.parentElement);
					var contentHTML='';
					if(Elem.nodeName!='#text')
							contentHTML=contentHTML+Elem.outerHTML;
					else
							contentHTML=contentHTML+Elem.nodeValue
					do
					{
						if(Elem==null)
						{
							alert('Selection is out of scope of parent element.');
							check=1;
							break;
						}
						Elem=Elem.nextSibling;
						if(Elem==null)
						{
							alert('Selection is out of scope of parent element.');
							check=1;
							break;
						}
						if(Elem.nodeName!='#text')
							contentHTML=contentHTML+Elem.outerHTML;
						else
							contentHTML=contentHTML+Elem.nodeValue
					}while(Elem!=range.endContainer.$.parentElement)
					if(check==0){
						$(newElem).insertBefore((emphasisTags.indexOf(range.startContainer.$.parentElement.nodeName.toLowerCase())==-1?range.startContainer.$.parentElement:range.startContainer.$.parentElement.parentElement));
						range.deleteContents();
						range.select();
						newElem.innerHTML=contentHTML;
					}
				}
				else
				{
					alert('No Selection found');
				}
			}			
//			for (z = 0; z < partStyles.length; z++) {
//				var tagname = document.createElement('button');
//				tagname.setAttribute('type', 'button');
//				tagname.setAttribute('data-tag', partStyles[z].toLowerCase());
//				//tagname.setAttribute('onclick', 'autoGetSelectedText(this)');
//				tagname.onclick=autoGetSelectedText;
//				tagname.setAttribute('class', 'button button2');
//				if(z != 0) {
//					tagname.setAttribute("style", "margin-left: 20pt");
//				}
//				var spantagname = document.createElement('span');
//				spantagname.setAttribute('style', 'font-size: 9pt; font-family: Arial, Helvetica, sans-serif;');
//				var tagnameLabel = document.createTextNode(partStyles[z]);
//				spantagname.appendChild(tagnameLabel);
//				tagname.appendChild(spantagname);
//				dialog.appendChild(tagname);
//			}





//			var breakTagname = document.createElement('br');
//			dialog.appendChild(breakTagname);
//			var break4Tagname = document.createElement('br');
//			dialog.appendChild(break4Tagname);

			// Step 2:
			var optionTag = document.createElement('span');
			optionTag.setAttribute('style', 'font-weight: bold;');
			
			var labeltextNode = document.createTextNode('Step 2: Apply Ref Group: ');
			optionTag.appendChild(labeltextNode);
			//dialog.appendChild(optionTag);

			var tagname1 = document.createElement('button');
			tagname1.setAttribute('type', 'button');
			tagname1.setAttribute('data-tag', 'ref-list');
			tagname1.onclick=autoGetSelectedText;
			//tagname1.setAttribute('onclick', 'autoGetSelectedText(this)');
			tagname1.setAttribute('class', 'button button2');
			tagname1.setAttribute("style", "margin-left: 3pt");
			var spantagname1 = document.createElement('span');
			spantagname1.setAttribute('style', 'font-size: 9pt; font-family: Arial, Helvetica, sans-serif;');
			var tagname1Label = document.createTextNode('Ref-Group');
			spantagname1.appendChild(tagname1Label);
			tagname1.appendChild(spantagname1);
			//dialog.appendChild(tagname1);


			var break5Tagname = document.createElement('br');
			dialog.appendChild(break5Tagname);
			var break6Tagname = document.createElement('br');
			//dialog.appendChild(break6Tagname);

			// Step 3:
			var option3Tag = document.createElement('span');
			option3Tag.setAttribute('style', 'font-weight: bold;');
			
			var label3textNode = document.createTextNode('Step 3: Sec Label Format: ');
			option3Tag.appendChild(label3textNode);
			//dialog.appendChild(option3Tag);


			var secform = document.createElement("input");
			secform.setAttribute("type", "text");
			secform.setAttribute("id", "sev2lev");
			secform.setAttribute("size", "3");
			secform.setAttribute("style", "margin-left: 2pt");
			//dialog.appendChild(secform);

			var option8Tag = document.createElement('span');
			option8Tag.setAttribute('style', 'font-weight: bold;');
			var label8textNode = document.createTextNode(' E.g. 1.1');
			option8Tag.appendChild(label8textNode);
			//dialog.appendChild(option8Tag);

//			var break10Tagname = document.createElement('br');
//			dialog.appendChild(break10Tagname);
//			var break11Tagname = document.createElement('br');
//			dialog.appendChild(break11Tagname);

			// Step 4:
			var option4Tag = document.createElement('span');
			option4Tag.setAttribute('style', 'font-weight: bold;');
			
			var label4textNode = document.createTextNode('Auto Style: ');
			option4Tag.appendChild(label4textNode);
			dialog.appendChild(option4Tag);


			var tagname3 = document.createElement('button');
			tagname3.setAttribute('type', 'button');
			tagname3.setAttribute('onclick', 'runAutoStyle("sev2lev")');
			tagname3.setAttribute('class', 'button button2');
			tagname3.setAttribute("style", "margin-left: 11pt");
			var spantagname3 = document.createElement('span');
			spantagname3.setAttribute('style', 'font-size: 9pt; font-family: Arial, Helvetica, sans-serif;');
			var tagname3Label = document.createTextNode('Auto-Style');
			spantagname3.appendChild(tagname3Label);
			tagname3.appendChild(spantagname3);
			dialog.appendChild(tagname3);

			
			var break16Tagname = document.createElement('br');
			dialog.appendChild(break16Tagname);
			var break17Tagname = document.createElement('br');
			dialog.appendChild(break17Tagname);
			
			// Step 5:
			var option5Tag = document.createElement('span');
			option5Tag.setAttribute('style', 'font-weight: bold;');
			var label5textNode = document.createTextNode('Character Style: ');
			option5Tag.appendChild(label5textNode);
			dialog.appendChild(option5Tag);
			
			var break14Tagname = document.createElement('br');
			dialog.appendChild(break14Tagname);
			var break15Tagname = document.createElement('br');
			dialog.appendChild(break15Tagname);
			
			
			
			var tagname4 = document.createElement('button');
			tagname4.setAttribute('type', 'button');
			tagname4.setAttribute('onclick', 'callAuthorScript()');
			tagname4.setAttribute('class', 'button button2');
			tagname4.setAttribute("style", "margin-left: 2pt");
			var spantagname4 = document.createElement('span');
			spantagname4.setAttribute('style', 'font-size: 9pt; font-family: Arial, Helvetica, sans-serif;');
			var tagname4Label = document.createTextNode('Author');
			spantagname4.appendChild(tagname4Label);
			tagname4.appendChild(spantagname4);
			dialog.appendChild(tagname4);

//			var tagname5 = document.createElement('button');
//			tagname5.setAttribute('type', 'button');
//			tagname5.setAttribute('onclick', 'runAffStyle()');
//			tagname5.setAttribute('class', 'button button2');
//			tagname5.setAttribute("style", "margin-left: 20pt");
//			var spantagname5 = document.createElement('span');
//			spantagname5.setAttribute('style', 'font-size: 9pt; font-family: Arial, Helvetica, sans-serif;');
//			var tagname5Label = document.createTextNode('Aff');
//			spantagname5.appendChild(tagname5Label);
//			tagname5.appendChild(spantagname5);
//			dialog.appendChild(tagname5);

			var tagname6 = document.createElement('button');
			tagname6.setAttribute('type', 'button');
			tagname6.setAttribute('onclick', 'runKwdStyle()');
			tagname6.setAttribute('class', 'button button2');
			tagname6.setAttribute("style", "margin-left: 20pt");
			var spantagname6 = document.createElement('span');
			spantagname6.setAttribute('style', 'font-size: 9pt; font-family: Arial, Helvetica, sans-serif;');
			var tagname6Label = document.createTextNode('kwdGrp');
			spantagname6.appendChild(tagname6Label);
			tagname6.appendChild(spantagname6);
			dialog.appendChild(tagname6);
			

			var break19Tagname = document.createElement('br');
			dialog.appendChild(break19Tagname);
			var break20Tagname = document.createElement('br');
			dialog.appendChild(break20Tagname);

			// Step 6:
			var option6Tag = document.createElement('span');
			option6Tag.setAttribute('style', 'font-weight: bold;');
			var label6textNode = document.createTextNode('Reference Char Style: ');
			option6Tag.appendChild(label6textNode);
			dialog.appendChild(option6Tag);

			var tagname7 = document.createElement('button');
			tagname7.setAttribute('type', 'button');
			tagname7.setAttribute('onclick', 'callrefScript()');
			tagname7.setAttribute('class', 'button button2');
			tagname7.setAttribute("style", "margin-left: 13pt");
			var spantagname7 = document.createElement('span');
			spantagname7.setAttribute('style', 'font-size: 9pt; font-family: Arial, Helvetica, sans-serif;');
			var tagname7Label = document.createTextNode('Ref-Style');
			spantagname7.appendChild(tagname7Label);
			tagname7.appendChild(spantagname7);
			dialog.appendChild(tagname7);
						

			var break25Tagname = document.createElement('br');
			dialog.appendChild(break25Tagname);
			var break26Tagname = document.createElement('br');
			dialog.appendChild(break26Tagname);

			// Step 7:
			var option11Tag = document.createElement('span');
			option11Tag.setAttribute('style', 'font-weight: bold;');
			//var label11textNode = document.createTextNode('Step 7: DOI and Pubmed ID Insertion: ');
			var label11textNode = document.createTextNode('DOI Insertion and Ref Validation: ');
			option11Tag.appendChild(label11textNode);
			dialog.appendChild(option11Tag);

			var break27Tagname = document.createElement('br');
			dialog.appendChild(break27Tagname);
			var break27Tagname = document.createElement('br');
			dialog.appendChild(break27Tagname);

			var tagname11 = document.createElement('button');
			tagname11.setAttribute('type', 'button');
			tagname11.setAttribute('onclick', 'calldoiInsert()');
			tagname11.setAttribute('class', 'button button2');
			tagname11.setAttribute("style", "margin-left: 1pt");
			var spantagname11 = document.createElement('span');
			spantagname11.setAttribute('style', 'font-size: 9pt; font-family: Arial, Helvetica, sans-serif;');
			var tagname11Label = document.createTextNode('Ref-Doi');
			spantagname11.appendChild(tagname11Label);
			tagname11.appendChild(spantagname11);
			dialog.appendChild(tagname11);


			// Step 7a:

			var tagname22 = document.createElement('button');
			tagname22.setAttribute('type', 'button');
			tagname22.setAttribute('onclick', 'callpubmedIdInsert()');
			tagname22.setAttribute('class', 'button button2');
			tagname22.setAttribute("style", "margin-left: 20pt");
			var spantagname22 = document.createElement('span');
			spantagname22.setAttribute('style', 'font-size: 9pt; font-family: Arial, Helvetica, sans-serif;');
			var tagname22Label = document.createTextNode('Pubmed ID');
			spantagname22.appendChild(tagname22Label);
			tagname22.appendChild(spantagname22);
			//dialog.appendChild(tagname22);
			
			// Step 8
			var break21Tagname = document.createElement('br');
			dialog.appendChild(break21Tagname);
			var break22Tagname = document.createElement('br');
			dialog.appendChild(break22Tagname);
			
			var option12Tag = document.createElement('span');
			option12Tag.setAttribute('style', 'font-weight: bold;');
			var label12textNode = document.createTextNode('Reference Organizer: ');
			option12Tag.appendChild(label12textNode);
			dialog.appendChild(option12Tag);

			var break23Tagname = document.createElement('br');
			dialog.appendChild(break23Tagname);
			var break24Tagname = document.createElement('br');
			dialog.appendChild(break24Tagname);


			var tagname23 = document.createElement('button');
			tagname23.setAttribute('type', 'button');
			tagname23.setAttribute('onclick', 'callAPAStyle()');
			tagname23.setAttribute('class', 'button button2');
			tagname23.setAttribute("style", "margin-left: 1pt");
			var spantagname23 = document.createElement('span');
			spantagname23.setAttribute('style', 'font-size: 9pt; font-family: Arial, Helvetica, sans-serif;');
			var tagname23Label = document.createTextNode('APA Style');
			spantagname23.appendChild(tagname23Label);
			tagname23.appendChild(spantagname23);
			dialog.appendChild(tagname23);

			var tagname24 = document.createElement('button');
			tagname24.setAttribute('type', 'button');
			tagname24.setAttribute('onclick', 'callAMAStyle()');
			tagname24.setAttribute('class', 'button button2');
			tagname24.setAttribute("style", "margin-left: 20pt");
			var spantagname24 = document.createElement('span');
			spantagname24.setAttribute('style', 'font-size: 9pt; font-family: Arial, Helvetica, sans-serif;');
			var tagname24Label = document.createTextNode('AMA Style');
			spantagname24.appendChild(tagname24Label);
			tagname24.appendChild(spantagname24);
			dialog.appendChild(tagname24);

			var tagname25 = document.createElement('button');
			tagname25.setAttribute('type', 'button');
			tagname25.setAttribute('onclick', 'callVANStyle()');
			tagname25.setAttribute('class', 'button button2');
			tagname25.setAttribute("style", "margin-left: 20pt");
			var spantagname25 = document.createElement('span');
			spantagname25.setAttribute('style', 'font-size: 9pt; font-family: Arial, Helvetica, sans-serif;');
			var tagname25Label = document.createTextNode('VAN Style');
			spantagname25.appendChild(tagname25Label);
			tagname25.appendChild(spantagname25);
			dialog.appendChild(tagname25);
			
			document.body.appendChild(dialog);
		// adding dialog to the editor
		//var myText = "rajesh comment";


	
		// Dialog function
		$("#dialog-6").dialog({
			autoOpen : false,

      position: { my: 'left', at: 'bottom+50' },
      height : '420',
      width : '350',
			//height : '600',
			//width : '350',
		});
		
}
});
