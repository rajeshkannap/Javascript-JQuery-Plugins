﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'fr-ca', {
	bold: 'Gras',
	italic: 'Italique',
	strike: 'Barré',
	subscript: 'Indice',
	superscript: 'Exposant',
	underline: 'Souligné'
} );
