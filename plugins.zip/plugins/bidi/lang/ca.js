﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'ca', {
	ltr: 'Direcció del text d\'esquerra a dreta',
	rtl: 'Direcció del text de dreta a esquerra'
} );
