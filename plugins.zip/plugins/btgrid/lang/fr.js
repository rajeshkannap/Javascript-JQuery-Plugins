"use strict"

CKEDITOR.plugins.setLang( 'btgrid', 'fr', {
	selNumCols: 'Sélectionnez le nombre de colonnes',
  genNrRows: 'Nombre de lignes à générer',
	infoTab: 'Info',
	createBtGrid: 'Créer une grille Bootstrap',
	editBtGrid: 'Editer la grille Bootstrap',
	numColsError:  'Choisissez un nombre de colonnes',
	numRowsError: 'Choisissez un nombre de lignes',
} );
