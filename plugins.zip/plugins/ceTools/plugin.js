CKEDITOR.plugins.add('ceTools', {
	ceTools_Lbls: {},
	init: function (editor) {
		// Icon process

		editor.addCommand('ceToolsDialog', new CKEDITOR.dialogCommand('ceToolsDialog'));
		editor.ui.addButton('ceTools', {
			label: 'CE Tools',
			command: 'ceToolsDialog',
			toolbar: 'cetools,20',
			icon: this.path + 'images/icon.png',
			click: function () {
				$("#ceTools_dialog").dialog("open");
			}
		});
		textFromTag = function (node) {
			var d = node.innerHTML;
			if (d.length == 0)
				return ('');
			return (d);
		}

		$.ajax({
			url: this.path+"config/config.xml?mid=" + (new Date()).getTime(),
			contentType: 'application/xml',
			complete: function (xhr, status) {
				

				var parser = new DOMParser();
				var xmldoc = parser.parseFromString(xhr.responseText, "text/xml");
				// Place the response in an XML document.
				//var xmldoc = result; //Connect.responseXML;
				var xmlalbums = xmldoc.getElementsByTagName('input');
				//Tab Nodes
				var styleTabs = ['Auto'];

				// Adding ceToolsDialog to the body
				var dialog_ce = document.createElement('div');
				dialog_ce.id = "ceTools_dialog";
				dialog_ce.setAttribute('title', 'ceTools');
				//var linkdiv = document.createElement('div');
				
				// adding dialog to the editor

				var tabdialog_cetools = document.createElement('div');
				tabdialog_cetools.id = "tabs";

				// Append tabs to dialog
				var tabdiv1 = document.createElement('div');
				tabdiv1.id = "tab1";
				tabdialog_cetools.appendChild(tabdiv1);

				for (z = 0; z < styleTabs.length; z++) {
					var inputNode = xmlalbums[0].getElementsByTagName(styleTabs[z]);
					var optionNodes = inputNode[0].getElementsByTagName('option');

					for (i = 0; i < optionNodes.length; i++) {
						optionNode = optionNodes[i];
						//marginatt
						var inputName = textFromTag(optionNode);
						editor.plugins.ceTools.ceTools_Lbls[inputName] = optionNode.getAttribute('command');
						//editor.plugins.ceTools.ceTools_Lbls.push(inputName);
						//var editor.plugins.ceTools.ceTools_Lbls[inputName]=[];
						//editor.plugins.ceTools.ceTools_Lbls[inputName].push(optionNode.getAttribute('command'));
						//Create Figure Check Box
						var ceTools_inputoption = document.createElement('input');
						ceTools_inputoption.setAttribute('type', 'radio');
						ceTools_inputoption.setAttribute('id', inputName);
						ceTools_inputoption.setAttribute('name', "cetool_options");
						ceTools_inputoption.setAttribute('style', 'margin-left:' + optionNode.getAttribute('left'));
						var optionTag = document.createElement('span');
						optionTag.setAttribute('style', 'font-weight: bold;');
						inputName=inputName.replace("_"," ");
						var labeltextNode = document.createTextNode(inputName);
						//labeltextNode=labeltextNode+" S";
						optionTag.appendChild(labeltextNode);
						if (z == 0) {
							tabdiv1.appendChild(ceTools_inputoption);
							tabdiv1.appendChild(optionTag);
							if (i % 2 == 1) {
								var breakTagname = document.createElement('br');
								tabdiv1.appendChild(breakTagname);
							}
						}
					}
					dialog_ce.appendChild(tabdialog_cetools);
				}
				document.body.appendChild(dialog_ce);

				// dialog function
				$("#ceTools_dialog").dialog({
					autoOpen: false,

					position: { my: 'left', at: 'bottom+50' },
					height: '180',
					width: '320',
//					open: function () {
//						$('#tabs').tabs({})
//					},
					buttons: {
						/* SelectAll: function () { //cancel
							Object.keys(editor.plugins.ceTools.ceTools_Lbls).forEach(function (key) {
								//var keyValue = editor.plugins.ceTools.ceTools_Lbls[key];
								eval("$('#" + key + "')[0].checked=true;");
							})

						},
						ClearAll: function () { //cancel
							Object.keys(editor.plugins.ceTools.ceTools_Lbls).forEach(function (key) {
								eval("$('#" + key + "').removeAttr('checked');");
							})
						}, */
						Start: function () { //cancel
							debugger;		
							var editorXml = editor.document; // [object Object] ... CKEditor object
							var xmldocNode = editorXml.$; // [object HTMLDocument] .... DOM object
							var artBody = xmldocNode.getElementsByTagName('article-body');
							currHighlight=artBody[0].getAttribute('highlight');
							var ldlCollection = xmldocNode.getElementsByTagName('ldl_highlight');
							if (ldlCollection.length > 0 ){
								alert("ERROR: Clear the highlighted words found in the document");
								return;				
							}
							Object.keys(editor.plugins.ceTools.ceTools_Lbls).forEach(function (key) {
								
								if (eval("$('#" + key + "')[0].checked") == true) {
									var keyValue = editor.plugins.ceTools.ceTools_Lbls[key];
									console.log("editor.commands." + keyValue + ".exec();");
									eval("editor.commands." + keyValue + ".exec();");
								}
							})
							msg.data('messageBox').default('Completed');
							$(this).dialog("close");
						},
						Exit: function () { //cancel
							$(this).dialog("close");
						}
					},
				});
			}
		});
	}
});
