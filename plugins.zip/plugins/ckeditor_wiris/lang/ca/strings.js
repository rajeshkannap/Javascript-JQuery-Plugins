var strings = new Array();
strings['cancel'] = 'Cancel·lar';
strings['accept'] = 'Acceptar';
strings['manual'] = 'Manual';
strings['latex'] = 'LaTeX';