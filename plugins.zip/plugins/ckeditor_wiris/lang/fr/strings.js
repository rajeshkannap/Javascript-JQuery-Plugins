var strings = new Array();
strings['cancel'] = 'Annuler';
strings['accept'] = 'OK';
strings['manual'] = 'Manuel';
strings['latex'] = 'LaTeX';