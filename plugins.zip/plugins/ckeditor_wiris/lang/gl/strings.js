var strings = new Array();
strings['cancel'] = 'Cancelar';
strings['accept'] = 'Aceptar';
strings['manual'] = 'Manual';
strings['latex'] = 'LaTeX';