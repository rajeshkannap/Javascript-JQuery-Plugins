var strings = new Array();
strings['cancel'] = 'ביטול';
strings['accept'] = 'אישור';
strings['manual'] = 'מדריך';
strings['latex'] = 'LaTeX';