var strings = new Array();
strings['cancel'] = 'Cancelar';
strings['accept'] = 'OK';
strings['manual'] = 'Manual';
strings['latex'] = 'LaTeX';